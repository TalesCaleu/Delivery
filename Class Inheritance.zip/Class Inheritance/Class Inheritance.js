

let operation, delta_pacer;

operation = 240;
delta_pacer = 1 / 60;



class Train{

    constructor(Position_X, Speed_X){
    
        this.Position_X = Position_X;
        this.Speed_X = Speed_X;
    
    }

    Movement_X(){

        this.Position_X += this.Speed_X * delta_pacer;

    }

}



class Rider extends Train{

    constructor(Position_X, Speed_X){
    
        super(Position_X, Speed_X);
    
    }

    // super(Movement_X){};

}



let Rider_1 = new Rider(0, 100);
let Train_1 = new Train(0, 100);


while(operation > 0){

    operation -= 1;
    Train_1.Movement_X();
    console.log("Train 1 moved to",Math.round(Train_1.Position_X),".");
    Rider_1.Movement_X();
    console.log("Rider 1 moved to",Math.round(Rider_1.Position_X),".");

    console.log("Operation set to",operation,".");

}