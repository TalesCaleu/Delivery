

let base, exponent, result, cycle_counter, parity, remainder;



function Return_Power_If_Parity_Matches(Source_Base, Source_Exponent, Source_Parity){

    cycle_counter = Source_Exponent;
    exponent = Source_Exponent
    result = 1;
    base = Source_Base;

    while(cycle_counter > 0){

        cycle_counter -= 1;
        result = result * base;

    }

    // console.log(base,"elevado a",exponent,"é igual a",result,".");

    parity = Source_Parity;

    remainder = (Source_Base / 2) - (Math.floor(Source_Base / 2));

    if(remainder <= 0){

        if(parity <= 0){

            console.log(base,"elevado a",exponent,"é igual a",result,".");
            return result;

        }

        if(parity > 0){

            console.log("O número não é par, por isso não será mostrado o resultado da potência.");
            return 0;

        }

    }

    if(remainder > 0){

        if(parity <= 0){

            console.log("O número não é ímpar, por isso não será mostrado o resultado da potência.");
            return 0;

        }

        if(parity > 0){

            console.log(base,"elevado a",exponent,"é igual a",result,".");
            return result;
            
        }
        
    }

}



base = Number(prompt("Digite um número do qual você quer saber a potência ou a paridade."));

exponent = 3;
parity = 0;

// exponent = Number(prompt("Digite o expoente ao qual você quer que a base seja elevada."));
// parity = Number(prompt("Digite 0 para par ou 1 para ímpar."));

Return_Power_If_Parity_Matches(base, exponent, parity);