CREATE DATABASE Course_Data;

USE Course_Data;

CREATE TABLE Student_Data(

    student_name text default null;
    age smallint default null;
    module smallint default null;
    misses smallint default null;
    subject_1_score smallint default null;
    subject_2_score smallint default null;
    subject_2_score smallint default null;

)

ALTER Student_Data(student_name = "Osnaldo");
ALTER Student_Data(age = "17");
ALTER Student_Data(module = "1");
ALTER Student_Data(misses = "0");

ALTER Student_Data(subject_1_score = 7);
ALTER Student_Data(subject_2_score = 8);
ALTER Student_Data(subject_3_score = 9);


CREATE TABLE TASKS (

    id int auto_increment not null primary key,
    tarefa varchar(85) not null,
    descrição text,
    responsavel varchar(85) not null
);

