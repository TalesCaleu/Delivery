



class Year_Math{

    constructor(Salary, Weekly_Hours, Yearly_Weeks, Yearly_Cost, Resulting_Wallet, Remaining_Weeks){
    
        this.Salary = Math.floor(Salary * 100) / 100;
        this.Weekly_Hours = Math.floor(Weekly_Hours);
        this.Yearly_Weeks = Math.floor(Yearly_Weeks);
        this.Yearly_Cost = Math.ceil(Yearly_Cost * 100) / 100;
        this.Resulting_Wallet = Math.floor(Resulting_Wallet * 100) / 100;
        this.Remaining_Weeks = Math.floor(Remaining_Weeks);
    
    }

    Initiate_Year(){

        console.log("Initiating year",(Bank_1.Total_Years - Bank_1.Remaining_Years) + 1,".");
        console.log("Only",Bank_1.Remaining_Years,"more years to go.");

        this.Remaining_Weeks = this.Yearly_Weeks;
        this.Weekly_Income();

    }

    Weekly_Income(){

        while(this.Remaining_Weeks > 0){

            this.Remaining_Weeks -= 1;
            console.log("One less week of work. Only",Math.ceil(this.Remaining_Weeks),"weeks remaining.");
            this.Resulting_Wallet += (this.Salary * this.Weekly_Hours);
            this.Resulting_Wallet = Math.round(this.Resulting_Wallet * 100) / 100;
            console.log("Wallet increased to $",Math.floor(this.Resulting_Wallet * 100) / 100,".");

        }

        this.Resulting_Wallet -= Math.ceil(this.Yearly_Cost * 100) / 100;
        console.log("Spent $",this.Yearly_Cost,"on costs.");
        console.log("Now there are $",Math.floor(this.Resulting_Wallet * 100) / 100,"remaining to deposit.");

        this.Deposit(this.Resulting_Wallet);

    }
    
    Deposit(Ammount){

        console.log("Bank stock was at $",Math.floor(Bank_1.Final_Stock * 100) / 100,"a year ago.");
        Bank_1.Final_Stock = Bank_1.Final_Stock * Bank_1.Yearly_Interest;
        console.log("Now it increased to $",Math.floor(Bank_1.Final_Stock * 100) / 100,"with the interest.");

        Bank_1.Final_Stock += Ammount;
        this.Resulting_Wallet -= Ammount;

        console.log("After the deposit, it's now at $",Math.floor(Bank_1.Final_Stock * 100) / 100,".");
        console.log("User wallet is now at $",Math.floor(this.Resulting_Wallet * 100) / 100,".");

        Bank_1.Deposit();
    
    }
    
}



class Total_Math{

    constructor(Total_Years, Raw_Deposit, Yearly_Interest, Final_Stock, Remaining_Years, Finished){
    
        this.Total_Years = Total_Years;
        this.Raw_Deposit = Raw_Deposit;
        this.Yearly_Interest = Yearly_Interest;
        this.Final_Stock = Final_Stock;
        this.Remaining_Years = Remaining_Years;
        this.Finished = Finished;
    
    }
    
    Initiate_Process(){

        this.Remaining_Years = this.Total_Years;
        this.Get_Money();

    }

    Get_Money(){

        while(this.Remaining_Years > 0){

            User_1.Initiate_Year();

        }

        if(this.Finished > 0){

            console.log("Cycle is finished.");

        }

        if(this.Finished < 1){

            console.log("PROBLEM DETECTED - Cycle is NOT finished!");

        }

    }

    Deposit(){
    
        this.Remaining_Years -= 1;
        
        if(this.Remaining_Years < 1){

            this.Finished = 1;

        }
    
    }
    
}



let User_1 = new Year_Math(36.40, 32, 48, 30993.44, 0, 0);
let Bank_1 = new Total_Math(20, 0, 1.1315, 0, 20, 0);

Bank_1.Initiate_Process();